# Client-side Sample for realtime quotes

This is an example on retrieving streaming quotes.

Live demo: https://saxobank.github.io/openapi-samples-js/sample-apps/realtime-quotes/
